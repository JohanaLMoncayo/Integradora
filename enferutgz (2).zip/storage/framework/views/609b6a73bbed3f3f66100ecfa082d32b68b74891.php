

<?php $__env->startSection('title', 'PACIENTES COVID'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Editar Paciente covid</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
   <form action="/pacicovis/<?php echo e($pacicovi->id); ?>" method="POST" class="formulario-editar">    
   <?php echo csrf_field(); ?>
   <?php echo method_field('PUT'); ?>
  <div class="mb-3">
    <label for="" class="form-label">Nombre</label>
    <input id="nombre" name="nombre" type="text" class="form-control" value="<?php echo e($pacicovi->nombre); ?>">    
  </div>
  <div class="mb-3">
    <label for="" class="form-label">Apellidos</label>
    <input id="apellido" name="apellido" type="text" class="form-control" value="<?php echo e($pacicovi->apellido); ?>">    
  </div>
  <div class="mb-3">
    <label for="" class="form-label">Carrera</label>
    <input id="carrera" name="carrera" type="text" class="form-control" value="<?php echo e($pacicovi->carrera); ?>">
  </div>
  <div class="mb-3">
    <label for="" class="form-label">Fecha Consulta</label>
    <input id="fechaconsulta" name="fechaconsulta" type="date" class="form-control" value="<?php echo e($pacicovi->fechaconsulta); ?>">    
  </div>
  <div class="mb-3">
    <label for="" class="form-label">Estatus</label>
    <input id="estatus" name="estatus" type="text" class="form-control" value="<?php echo e($pacicovi->estatus); ?>">    
  </div>
  <a href="/pacicovis" class="btn btn-secondary">Cancelar</a>
  <button type="submit" class="btn btn-primary">Guardar</button>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>  
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
    $('.formulario-editar').submit(function(e){
e.preventDefault();
Swal.fire({
  title: '¿Estas seguro que quieres editar este elemento?',
  icon: 'warning',
  showCancelButton: false,
  confirmButtonColor: '#3085d6',
  cancelButtonColor: '#d33',
  confirmButtonText: 'Si, editar elemento'
}).then((result) => {
  if (result.isConfirmed) {
    this.submit();
  }
})
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\enferutgz\resources\views/pacicovi/edit.blade.php ENDPATH**/ ?>
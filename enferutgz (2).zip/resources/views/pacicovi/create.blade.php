@extends('adminlte::page')

@section('title', 'PACIENTES COVID')

@section('content_header')
   <h1>Registrar Paciente Covid</h1>
@stop

@section('content')
    
<form action="/pacicovis" method="POST" class="formulario-guardar">
  @csrf
  <div class="mb-3">
    <label for="" class="form-label">Nombre</label>
    <input id="nombre" name="nombre" type="text" class="form-control" tabindex="1">    
  </div>
  <div class="mb-3">
    <label for="" class="form-label">Apellidos</label>
    <input id="apellido" name="apellido" type="text" class="form-control" tabindex="1">    
  </div>
  <div class="mb-3">
    <label for="" class="form-label">Carrera</label>
    <input id="carrera" name="carrera" type="text" class="form-control" tabindex="3">
  </div>
  <div class="mb-3">
    <label for="" class="form-label">Fecha de consulta</label>
    <input id="fechaconsulta" name="fechaconsulta" type="date" class="form-control" tabindex="1">    
  </div>
  <div class="mb-3">
    <label for="" class="form-label">Estatus</label>
    <input id="estatus" name="estatus" type="estatus" class="form-control" tabindex="1">    
  </div>
  <a href="/pacicovi" class="btn btn-secondary" tabindex="5">Cancelar</a>
  <button type="submit" class="btn btn-primary " tabindex="4">Guardar</button>
</form>
@stop

@section('css')
    <link rel="stylesheet" href="/css/admin_custom.css">
@stop

@section('js')  

<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
    $('.formulario-guardar').submit(function(e){

Swal.fire({
  position: 'top-center',
  icon: 'success',
  title: 'Se ha guardado correctamente',
  showConfirmButton: false,
  timer: 2000
})

    });
</script>
@stop